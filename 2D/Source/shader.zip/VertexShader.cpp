#include "VertexShader.h"

VertexShader::uniforms_t VertexShader::uniforms =
{
	//
};

void VertexShader::Process(const vertex_t& ivertex, vertex_output_t& overtex)
{
	//
}
